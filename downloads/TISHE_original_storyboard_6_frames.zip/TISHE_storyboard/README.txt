TISHE - original storyboard frames (01-06)
Frame sequence: city / headphones / folding city / shrinking city / miniature city / final title.
Format: 1672 x 941 WebP. All images are unaltered original files from wolfcubmusic/portfolio, main, assets/images/tishe/.
These frames illustrate a sequence; they are not an edge-continuous sliced panoramic carousel.
